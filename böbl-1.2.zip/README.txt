WELCOME TO BÖBL 1.2

This little bubble got some new tricks up its sleeve.

We brought back auto scrollers from the pit of bad game design. Now let us sell
water levels to you!

You will need a flash cart or NES emulator to play: Mesen recommended.

   ÖÖÖÖÖ   
 ÖÖ     ÖÖ 
Ö  ÖÖ     Ö
Ö  Ö      Ö
Ö      Ö  Ö
 ÖÖ     ÖÖ 
   ÖÖÖÖÖ   

CONTENTS
1) CONTROLS
2) ZEN MODE
3) GHOST
4) DUCK RANDOMIZER
5) LINKS
6) CHANGELOG


1) CONTROLS

Hold A to dive, let go to jump.

Water is your friend, solids make you pop!!

Collect powerups to unlock more mechanics:

Iron Böbl
- use it to clear breakable blocks
- can bounce off solid tiles once without dying

Double Jump
- press B in mid-air
- climb waterfalls: hold B coming out sideways of a waterfall tile

Hold Select+A+B to reset to the options screen.


2) ZEN MODE

Got a kid or find the game a little too punishing?

This setting lets you explore Böbl without deaths.


3) GHOST

Böbl is meant to be a short game with replay value. Now you can race your own
ghost à la Mario Kart Time Trial.

Your emulator or flash cart need to support the FME-7 mapper with 32KB of
battery-backed SRAM. Some emulators top out at 8KB, which breaks the ghost
recording feature.

Roughly 10-15 minutes of gameplay can be recorded.

Tested and working emulators are: Mesen, FCEUX >=2.2.3


You can share ghosts with your friends by exchanging SRAM saves. For emulators,
this is usually a .sav file located in the emulator directory. Make sure to
close your emulator before grabbing the file, so the new save data is flushed
to the disk.

We had issues when launching the ROM from Mesen's preview of recently played
games. Apparently, it loads from a save state when you click one of the preview
screens, which overwrites the existing SRAM save, so make sure to load the ROM
from your disk (via drag'n drop or File/Open) after you copy a new .sav file to
Mesen's save directory.


At the end of a run, your play time is shown as a frame count. An NTSC NES runs
at ~60.1 frames per second.


4) DUCK RANDOMIZER

In the randomizer, each duck will choose one of three possible spawn locations.
Here is a list of ducks, their icons and hints on their preferred habitats:

DEADEYE (eyeball) - likes to ride the waves
SCROOGE ($) - wants you to pop
DARKWING (hat) - keeps the deep sea free of crime
AFLACK (cloud) - obsessed with clouds
HOWARD (star) - close to space
FERDINAND (house) - afraid of open spaces
PLUCKY (feather) - pluck him out of from under a ceiling
WILDWING (steam) - spa aficionado

The Warp Flute's location is completely random, sometimes it may not be
accessible or not appear in a run at all, e.g. if the game attempts to spawn it
in an unused screen of the map.


5) LINKS
Check out our other games on https://morphcatgames.itch.io
Physical NES/Famicom releases at https://www.brokestudio.fr/

We're aiming for a cartridge release of Böbl some time in the future.

http://morphcat.de
http://twitter.com/morphcat
https://discord.gg/g2fdSwy



6) CHANGELOG
Version 1.2 - FROG UPDATE
November 2021
	- added options screen
	- added ghost feature
	- added duck randomizer
	- added warp flute
	- added waterfall jump mechanic
	- added scrolling
	- added zippy spiral pipes
	- duck names are canon!
	- added credits screen
	- added zen mode
	- fixed more palette bugs and another softlock
	- fixed sound bugs

Version 1.1 - BUG SQUASH UPDATE
November 3, 2020
	- fixed out of bounds bugs
	- fixed random black screen/softlock

